package com.rustcraft.client;

import com.mojang.blaze3d.shaders.FogShape;
import com.rustcraft.common.ClientState;
import com.rustcraft.net.ActionPacket;
import com.rustcraft.net.NetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

/**
 * Клиент: клавиша P, красное зрение терминатора, туман, сканер (подсветка, линия, рамки целей) и HUD.
 * Сам HUD и эффекты экрана нарисованы в TerminatorHud.java.
 * Индекс в массивах ниже = уровень системы (0 повреждён, 1 средний, 2 максимальный).
 */
@Mod.EventBusSubscriber(modid = "rustcraft", value = Dist.CLIENT)
public class ClientEvents {
    // Сканер: как часто бежит линия / подсвечиваются сущности, на сколько тиков, и радиус.
    private static final int[] LINE_INTERVAL = {100, 60, 40};
    private static final int[] HL_INTERVAL = {100, 60, 20};
    private static final int[] HL_DURATION = {40, 40, 30};
    private static final double[] RADIUS = {16.0, 32.0, 48.0};
    private static final int LINE_SWEEP_TICKS = 20;

    private static final Random FX = new Random();
    private static final int RED = 0xFF2828;

    private static int tick = 0;
    private static int lineStart = -1000;
    /** Время включения терминатора (для заставки загрузки) и был ли он включён в прошлом тике. */
    private static int bootStart = -1000;
    private static boolean wasActive = false;
    /** Какой пост-шейдер сейчас включён (null = никакого). */
    private static ResourceLocation shaderLoaded = null;
    /** Красный монохромный экран - зрение терминатора на всех уровнях. */
    private static final ResourceLocation SHADER_RED = new ResourceLocation("rustcraft", "shaders/post/red_vision.json");
    private static LocalPlayer lastPlayer = null;
    /** id существа -> тик, когда подсветку надо выключить. */
    private static final Map<Integer, Integer> highlighted = new HashMap<>();

    // ---------- Клавиша P ----------
    private static void handleKey(Minecraft mc) {
        while (KeyBindings.TERMINATOR_KEY.consumeClick()) {
            if (mc.player == null || mc.screen != null) continue;   // только в игре, не поверх других окон
            if (!ClientState.active) {
                // Ещё человек -> P делает тебя терминатором (навсегда)
                NetworkHandler.CHANNEL.sendToServer(new ActionPacket(ActionPacket.ACTIVATE, 0));
            } else {
                // Уже терминатор -> P открывает слоты улучшений
                mc.setScreen(new UpgradeScreen());
            }
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        handleKey(mc);

        // Нет мира — всё сбрасываем
        if (mc.player == null || mc.level == null) {
            shaderLoaded = null;
            wasActive = false;
            highlighted.clear();
            lastPlayer = null;
            return;
        }
        if (mc.player != lastPlayer) { // новый игрок (респавн/смена мира)
            lastPlayer = mc.player;
            shaderLoaded = null;
            highlighted.clear();
        }
        tick++;

        // Только что стали терминатором (или зашли в мир уже терминатором) -> запускаем заставку загрузки
        if (ClientState.active && !wasActive) bootStart = tick;
        wasActive = ClientState.active;

        // Красный экран на всех уровнях зрения (чистота картинки зависит от уровня, см. TerminatorHud)
        ResourceLocation wantShader = ClientState.active ? SHADER_RED : null;
        if (!Objects.equals(wantShader, shaderLoaded)) {
            if (wantShader == null) mc.gameRenderer.shutdownEffect();
            else mc.gameRenderer.loadEffect(wantShader);
            shaderLoaded = wantShader;
        }

        if (ClientState.active) {
            int s = ClientState.scanner;
            if (tick % LINE_INTERVAL[s] == 0) lineStart = tick;          // запускаем бегущую линию
            if (tick % HL_INTERVAL[s] == 0) {                            // подсвечиваем ближние сущности
                double r2 = RADIUS[s] * RADIUS[s];
                for (Entity other : mc.level.entitiesForRendering()) {   // ВСЕ сущности: мобы, животные, игроки, предметы...
                    if (other == mc.player) continue;
                    if (mc.player.distanceToSqr(other) <= r2) {
                        highlighted.put(other.getId(), tick + HL_DURATION[s]);
                    }
                }
            }
        } else if (!highlighted.isEmpty()) {                             // перестали быть терминатором — гасим подсветку
            for (Integer id : highlighted.keySet()) setGlow(mc, id, false);
            highlighted.clear();
        }

        // Выключаем подсветку, когда вышло время
        Iterator<Map.Entry<Integer, Integer>> it = highlighted.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Integer> en = it.next();
            if (en.getValue() <= tick) {
                setGlow(mc, en.getKey(), false);
                it.remove();
            } else {
                setGlow(mc, en.getKey(), true);
            }
        }
    }

    private static void setGlow(Minecraft mc, int id, boolean glow) {
        if (mc.level == null) return;
        Entity ent = mc.level.getEntity(id);
        if (ent == null) return;
        ent.setGlowingTag(glow);
        forceGlowFlag(ent, glow); // на клиенте setGlowingTag сам флаг не меняет, поэтому ставим его напрямую
    }

    private static Method setSharedFlag;
    private static boolean setSharedFlagResolved = false;

    /** Entity.setSharedFlag(6, glow) — бит 6 = "светится". Метод protected, берём через рефлексию (SRG-имя m_20115_). */
    private static void forceGlowFlag(Entity ent, boolean glow) {
        if (!setSharedFlagResolved) {
            setSharedFlagResolved = true;
            try {
                setSharedFlag = ObfuscationReflectionHelper.findMethod(Entity.class, "m_20115_", int.class, boolean.class);
            } catch (Throwable t) {
                setSharedFlag = null; // не нашли — остаётся только обычный setGlowingTag
            }
        }
        if (setSharedFlag == null) return;
        try {
            setSharedFlag.invoke(ent, 6, glow);
        } catch (Throwable ignored) {
        }
    }

    // ---------- Зрение: туман (уровни 0 и 1) ----------
    @SubscribeEvent
    public static void onFog(ViewportEvent.RenderFog e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        float far = ClientState.vision == 0 ? 6.0f : 24.0f;
        e.setNearPlaneDistance(0f);
        e.setFarPlaneDistance(far);
        e.setFogShape(FogShape.SPHERE);
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onFogColor(ViewportEvent.ComputeFogColor e) {
        if (!ClientState.active || ClientState.vision >= 2) return;
        e.setRed(0f);
        e.setGreen(0f);
        e.setBlue(0f);
    }

    /** Лёгкая тряска кадра при повреждённом зрении (только наклон, прицел не сбивается). */
    @SubscribeEvent
    public static void onCameraAngles(ViewportEvent.ComputeCameraAngles e) {
        if (!ClientState.active || ClientState.vision != 0) return;
        float shake = (float) (Math.sin((tick + e.getPartialTick()) * 0.9) * 0.35 + (FX.nextFloat() - 0.5f) * 0.4f);
        e.setRoll(e.getRoll() + shake);
    }

    // ---------- Эффекты экрана (под интерфейсом) ----------
    @SubscribeEvent
    public static void onGuiPre(RenderGuiEvent.Pre e) {
        if (!ClientState.active) return;
        TerminatorHud.renderScreenFx(e.getGuiGraphics(), e.getWindow().getGuiScaledWidth(),
                e.getWindow().getGuiScaledHeight(), tick, ClientState.vision);
    }

    // ---------- Рамки целей: перевод координат мира в координаты экрана ----------
    private static final Matrix4f projView = new Matrix4f();
    private static Vec3 camPos = Vec3.ZERO;
    private static boolean projValid = false;

    /** Запоминаем матрицы камеры, чтобы потом перевести координаты существа из мира в координаты экрана. */
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        if (!ClientState.active) {
            projValid = false;
            return;
        }
        projView.set(e.getProjectionMatrix()).mul(e.getPoseStack().last().pose());
        camPos = e.getCamera().getPosition();
        projValid = true;
    }

    /** Рамка-уголки вокруг каждого подсвеченного ЖИВОГО существа + имя, расстояние и здоровье. Ближайшая цель "захвачена". */
    @SubscribeEvent
    public static void onGuiTargets(RenderGuiEvent.Post e) {
        if (!ClientState.active || !projValid || highlighted.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        GuiGraphics g = e.getGuiGraphics();
        Font font = mc.font;
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        float pt = e.getPartialTick();
        boolean glitch = ClientState.vision == 0; // при повреждённом зрении рамки дёргаются, а подписи рассыпаются

        // ближайшая живая цель = "захват"
        int lockedId = -1;
        double best = Double.MAX_VALUE;
        for (Integer id : highlighted.keySet()) {
            Entity en = mc.level.getEntity(id);
            if (!(en instanceof LivingEntity)) continue;
            double d = mc.player.distanceToSqr(en);
            if (d < best) { best = d; lockedId = id; }
        }

        for (Integer id : highlighted.keySet()) {
            Entity ent = mc.level.getEntity(id);
            if (!(ent instanceof LivingEntity le)) continue;

            // положение с учётом сглаживания между тиками
            double ox = Mth.lerp(pt, ent.xo, ent.getX()) - ent.getX();
            double oy = Mth.lerp(pt, ent.yo, ent.getY()) - ent.getY();
            double oz = Mth.lerp(pt, ent.zo, ent.getZ()) - ent.getZ();
            AABB box = ent.getBoundingBox().move(ox, oy, oz);

            // проецируем 8 углов коробки на экран
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean visible = true;
            for (int i = 0; i < 8; i++) {
                double cx = (i & 1) == 0 ? box.minX : box.maxX;
                double cy = (i & 2) == 0 ? box.minY : box.maxY;
                double cz = (i & 4) == 0 ? box.minZ : box.maxZ;
                Vector4f v = new Vector4f((float) (cx - camPos.x), (float) (cy - camPos.y), (float) (cz - camPos.z), 1f);
                projView.transform(v);
                if (v.w <= 0.05f) { visible = false; break; }   // позади камеры
                float sx = (v.x / v.w * 0.5f + 0.5f) * w;
                float sy = (1f - (v.y / v.w * 0.5f + 0.5f)) * h;
                minX = Math.min(minX, sx); maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy); maxY = Math.max(maxY, sy);
            }
            if (!visible || maxX < 0 || minX > w || maxY < 0 || minY > h) continue;

            int x0 = (int) minX, y0 = (int) minY, x1 = (int) maxX, y1 = (int) maxY;
            if (x1 - x0 < 8) { int c = (x0 + x1) / 2; x0 = c - 4; x1 = c + 4; }
            if (y1 - y0 < 8) { int c = (y0 + y1) / 2; y0 = c - 4; y1 = c + 4; }
            if (glitch && FX.nextInt(3) == 0) {               // дёрганье рамки
                int jx = FX.nextInt(5) - 2, jy = FX.nextInt(5) - 2;
                x0 += jx; x1 += jx; y0 += jy; y1 += jy;
            }

            boolean locked = id == lockedId;
            int col = (ent instanceof Enemy) ? 0xFFFF3030 : 0xFFE89090;   // враги ярко-красные
            corners(g, x0, y0, x1, y1, col);
            if (locked) {                                                  // захват цели: вторая рамка снаружи, мигающая
                int pad = 5 + (int) Math.round(Math.sin(tick * 0.4) * 1.5);
                corners(g, x0 - pad, y0 - pad, x1 + pad, y1 + pad, 0xFFFFA0A0);
            }

            // подписи: [LOCKED], имя, затем расстояние и здоровье
            String name = ent.getName().getString().toUpperCase(Locale.ROOT);
            String info = Math.round(mc.player.distanceTo(ent)) + " m   HP " + Math.round(le.getHealth());
            if (glitch && FX.nextInt(4) == 0) { name = TerminatorHud.junk(name); info = TerminatorHud.junk(info); }
            int lines = locked ? 3 : 2;
            int ty = (y0 > 14 + lines * 10) ? y0 - lines * 10 - (locked ? 6 : 0) : y1 + 3 + (locked ? 6 : 0);
            if (locked) {
                g.drawString(font, "TARGET LOCKED", x0, ty, 0xFFFFA0A0, false);
                ty += 10;
            }
            g.drawString(font, name, x0, ty, col, false);
            g.drawString(font, info, x0, ty + 10, col, false);
        }
    }

    /** Четыре уголка-рамки. */
    private static void corners(GuiGraphics g, int x0, int y0, int x1, int y1, int col) {
        int lx = Math.max(3, Math.min(12, (x1 - x0) / 3));
        int ly = Math.max(3, Math.min(12, (y1 - y0) / 3));
        g.fill(x0, y0, x0 + lx, y0 + 1, col);  g.fill(x0, y0, x0 + 1, y0 + ly, col);      // левый верх
        g.fill(x1 - lx, y0, x1, y0 + 1, col);  g.fill(x1 - 1, y0, x1, y0 + ly, col);      // правый верх
        g.fill(x0, y1 - 1, x0 + lx, y1, col);  g.fill(x0, y1 - ly, x0 + 1, y1, col);      // левый низ
        g.fill(x1 - lx, y1 - 1, x1, y1, col);  g.fill(x1 - 1, y1 - ly, x1, y1, col);      // правый низ
    }

    // ---------- HUD терминатора (компас, прицел, панели, заставка) ----------
    @SubscribeEvent
    public static void onGuiHud(RenderGuiEvent.Post e) {
        if (!ClientState.active) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        int targets = 0, hostiles = 0;
        for (Integer id : highlighted.keySet()) {
            Entity en = mc.level.getEntity(id);
            if (!(en instanceof LivingEntity)) continue;
            targets++;
            if (en instanceof Enemy) hostiles++;
        }

        double rng = -1;
        HitResult hr = mc.hitResult;
        if (hr != null && hr.getType() != HitResult.Type.MISS) {
            rng = hr.getLocation().distanceTo(mc.player.getEyePosition());
        }

        float t = (tick - lineStart) + e.getPartialTick();
        float scanProgress = (t >= 0 && t < LINE_SWEEP_TICKS) ? t / LINE_SWEEP_TICKS : -1f;

        TerminatorHud.renderHud(e.getGuiGraphics(), mc.font, e.getWindow().getGuiScaledWidth(),
                e.getWindow().getGuiScaledHeight(), mc.player.getYRot(), tick, tick - bootStart, scanProgress,
                targets, hostiles, (int) RADIUS[ClientState.scanner], rng,
                mc.player.getHealth(), mc.player.getMaxHealth());
    }

    // ---------- Сканер: бегущая красная линия сверху вниз со шлейфом ----------
    @SubscribeEvent
    public static void onGuiPost(RenderGuiEvent.Post e) {
        if (!ClientState.active) return;
        float t = (tick - lineStart) + e.getPartialTick();
        if (t < 0 || t >= LINE_SWEEP_TICKS) return;
        int w = e.getWindow().getGuiScaledWidth();
        int h = e.getWindow().getGuiScaledHeight();
        int y = (int) (t / LINE_SWEEP_TICKS * h);
        GuiGraphics g = e.getGuiGraphics();
        for (int i = 0; i < 10; i++) {                                   // шлейф над линией
            g.fill(0, y - 2 - (i + 1) * 3, w, y - 2 - i * 3, TerminatorHud.argb(0x38 - i * 5, RED));
        }
        g.fill(0, y - 2, w, y + 2, 0xFFFF3030);
        g.fill(0, y, w, y + 1, 0xFFFFC0C0);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientState.reset();
        highlighted.clear();
        shaderLoaded = null;
        wasActive = false;
        projValid = false;
    }
}

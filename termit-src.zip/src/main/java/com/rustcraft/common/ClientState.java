package com.rustcraft.common;

/** Копия состояния терминатора на стороне клиента (приходит пакетом SyncPacket). */
public final class ClientState {
    public static volatile boolean active;
    public static volatile int vision;
    public static volatile int memory;
    public static volatile int scanner;

    private ClientState() {}

    public static void reset() {
        active = false;
        vision = 0;
        memory = 0;
        scanner = 0;
    }

    /** Уровень системы по номеру слота (0 = зрение, 1 = память, 2 = сканер). */
    public static int level(int system) {
        return system == 0 ? vision : system == 1 ? memory : scanner;
    }
}
